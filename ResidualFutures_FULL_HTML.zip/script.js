let E={regret:0,longing:0,denial:0,acceptance:0,dissonance:0};
let gaze=0,start=Date.now(),spoken="";
const lines=["You stayed longer last time.","This choice already happened.","I remember you differently.","You were never supposed to see this.","This isn't the first ending."];
const w=document.getElementById("world"),d=document.getElementById("dialogue"),o=document.getElementById("overlay");
function interact(x,y){let dx=x-innerWidth/2,dy=y-innerHeight/2,dist=Math.sqrt(dx*dx+dy*dy);
if(dist<120){gaze++;E.regret+=0.002;E.longing+=0.001}else{gaze=Math.max(0,gaze-1);E.dissonance+=0.001}update();}
document.onmousemove=e=>interact(e.clientX,e.clientY);
document.ontouchmove=e=>interact(e.touches[0].clientX,e.touches[0].clientY);
function update(){w.style.filter=`blur(${Math.min(8,E.dissonance*25)}px)`;
w.style.transform=`scale(${1+E.regret*0.06}) rotate(${E.longing*2}deg)`;
o.style.opacity=Math.abs(E.denial);
if(gaze>150&&Math.random()<.03)speak();checkEnd();}
function speak(){let t;do{t=lines[Math.floor(Math.random()*lines.length)]}while(t===spoken);
spoken=t;d.textContent=t;setTimeout(()=>{if(Math.random()<.6)d.textContent=""},3500);}
function checkEnd(){let t=(Date.now()-start)/1000;if(t>300){document.body.innerHTML="";
document.body.style.background="#000";
document.body.innerText=E.regret>E.acceptance?"You keep returning.":"You fade without resolution.";}}